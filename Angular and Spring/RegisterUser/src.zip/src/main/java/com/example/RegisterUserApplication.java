package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.example.models.User;

@SpringBootApplication
public class RegisterUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterUserApplication.class, args);
	}


}
